create procedure helloWorld
as
begin
	print 'hello world'
end

exec helloWorld